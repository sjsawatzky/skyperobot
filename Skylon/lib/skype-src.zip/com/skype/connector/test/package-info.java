/**
 * Provides the connector for testing
 */
package com.skype.connector.test;
