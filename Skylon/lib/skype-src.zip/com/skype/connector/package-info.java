/**
 * Provides the classes for the connector
 */
package com.skype.connector;
