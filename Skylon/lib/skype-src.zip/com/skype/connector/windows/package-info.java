/**
 * Provides the connector for Windows
 */
package com.skype.connector.windows;
